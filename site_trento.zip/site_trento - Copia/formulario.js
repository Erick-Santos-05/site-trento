function validarSenha(senha) {
    const letraMaiuscula = /[A-Z]/;
    const caracterEspecial = /[\W_]/;
    const contemNumero = /[0-9]/;

    return {
        letraMaiuscula: letraMaiuscula.test(senha),
        caracterEspecial: caracterEspecial.test(senha),
        contemNumero: contemNumero.test(senha),
    };
}

function validarIdade(idade) {
    return idade >= 18;
}

function validarConfirmacaoSenha(senha, confirmacao) {
    return senha === confirmacao;
}

function enviarFormulario(idade, senha, confSenha) {
    if (!validarIdade(idade)) {
        return 'Menores de 18 anos não podem enviar o formulário!';
    }

    if (!validarConfirmacaoSenha(senha, confSenha)) {
        return 'Senhas diferentes.';
    }

    const regrasSenha = validarSenha(senha);
    if (!regrasSenha.letraMaiuscula || !regrasSenha.caracterEspecial || !regrasSenha.contemNumero) {
        return 'Senha inválida.';
    }

    return 'Formulário enviado com sucesso!';
}

module.exports = {
    validarSenha,
    validarIdade,
    validarConfirmacaoSenha,
    enviarFormulario
};



var conjunto = {nome: 'erick', idade: '18', sexo:'casual'}

// var senha = document.getElementById('senha');
// var carMan = document.getElementById('carMan');
// var carEsp = document.getElementById('carEspecial');
// var carNum = document.getElementById('carNum');
// var letraMaiscula = /[A-Z]/;
// var caracterEspecial = /[\W_]/;
// var contemNum = /[0-9]/;

// senha.addEventListener('input', function () {
//     if (letraMaiscula.test(senha.value)) {
//         carMan.innerHTML = '&#x2714;'
//     } else {
//         carMan.innerHTML = '&#x274C;'
//     }

//     if (caracterEspecial.test(senha.value)) {
//         carEsp.innerHTML = '&#x2714;'
//     } else {
//         carEsp.innerHTML = '&#x274C;'
//     }

//     if (contemNum.test(senha.value)) {
//         carNum.innerHTML = '&#x2714;'
//     } else {
//         carNum.innerHTML = '&#x274C;'
//     }
// });
// var estado = document.getElementById('estado');
// estado.addEventListener('change', estadoSel);

// let selecaoCidade = document.getElementById('cidade');

// function estadoSel(evento) {
//     selecaoEstado = evento.target.value

//     selecaoCidade.style.display = 'block'

//     selecaoCidade.innerHTML = '';
//     let cid0 = document.createElement('option');
//     cid0.text = 'Selecione uma cidade';
//     cid0.selected = true
//     cid0.disabled = true
//     selecaoCidade.appendChild(cid0)

//     if (selecaoEstado == 'MG') {
//         let cid1 = document.createElement('option');
//         cid1.text = 'Nova Lima'
//         selecaoCidade.appendChild(cid1)

//         let cid2 = document.createElement('option');
//         cid2.text = 'Belo Horizonte'
//         selecaoCidade.appendChild(cid2)

//         let cid3 = document.createElement('option');
//         cid3.text = 'Brumadinho'
//         selecaoCidade.appendChild(cid3)

//     } else if (selecaoEstado == 'SP') {
//         let cid1 = document.createElement('option');
//         cid1.text = 'São Paulo'
//         selecaoCidade.appendChild(cid1)

//         let cid2 = document.createElement('option');
//         cid2.text = 'Sorocaba'
//         selecaoCidade.appendChild(cid2)

//         let cid3 = document.createElement('option');
//         cid3.text = 'Santos'
//         selecaoCidade.appendChild(cid3)
//     } else if (selecaoEstado == 'RJ') {
//         let cid1 = document.createElement('option');
//         cid1.text = 'Rio de Janeiro'
//         selecaoCidade.appendChild(cid1)

//         let cid2 = document.createElement('option');
//         cid2.text = 'Nitéroi'
//         selecaoCidade.appendChild(cid2)

//         let cid3 = document.createElement('option');
//         cid3.text = 'Petrópolis'
//         selecaoCidade.appendChild(cid3)
//     } else if (selecaoEstado == 'ES') {
//         let cid1 = document.createElement('option');
//         cid1.text = 'Guarapari'
//         selecaoCidade.appendChild(cid1)

//         let cid2 = document.createElement('option');
//         cid2.text = 'Vitória'
//         selecaoCidade.appendChild(cid2)

//         let cid3 = document.createElement('option');
//         cid3.text = 'Alegre'
//         selecaoCidade.appendChild(cid3)
//     }
// }

// function enviar() {
//     var capNome = document.getElementById('nome');
//     var nome = capNome.value;
//     var capEmail = document.getElementById('email');
//     var email = capEmail.value;
//     var capIdade = document.getElementById('idade');
//     var idade = capIdade.value;
//     parseInt(idade)
//     var capSenha = document.getElementById('senha');
//     var senha = capSenha.value;
//     var capConfsenha = document.getElementById('confsenha');
//     var confsenha = capConfsenha.value;

//     if (idade < 18) {
//         alert('Menores de 18 anos não podem enviar o formulário!')
//         return;
//     }

//     if (senha !== confsenha) {
//         alert('Senhas diferentes.')
//         return;
//     }
//     if (!letraMaiscula.test(senha)) {
//         alert('senha inválida.')
//         return;
//     }
//     if (!caracterEspecial.test(senha)) {
//         alert('senha inválida.')
//         return;
//     }
//     if (!contemNum.test(senha)) {
//         alert('senha inválida.')
//         return;
//     }

// }
// var texto = document.getElementById('texto');
// var resul = document.getElementById('feedback');

// texto.addEventListener('input', function () {
//     var quantCaracter = texto.value.length

//     resul.innerHTML = `${500 - quantCaracter}/500`
//     if (quantCaracter == 500) {
//         alert('Máximo de caracters atingido.')
//     }
// });

// let controle = 1
// function cor() {
//     let root = document.documentElement;
//     if (controle == 1) {
//         root.style.setProperty('--cor1', '#6FF3C0');
//         root.style.setProperty('--cor2', '#38FFC6');
//         root.style.setProperty('--cor3', '#2BD6DE');
//         controle = 0
//     } else if (controle == 0) {
//         root.style.setProperty('--cor1', '#900C3F');
//         root.style.setProperty('--cor2', '#C70039');
//         root.style.setProperty('--cor3', '#D42921');
//         controle = 1
//     }
// }

// let font = 1

// function aumentarFont() {
//     font = Math.min(font + 0.01, 1.1);
//     document.body.style.fontSize = `${font}em`
// }

// function diminuirFont() {
//     font = Math.max(font - 0.01, 0.8);
//     document.body.style.fontSize = `${font}em`
// }